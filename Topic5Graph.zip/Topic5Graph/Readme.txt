Youtube video link:
https://youtu.be/zcMMkyz9u_M?si=vPV1QjEzkp4qBeb7

Video playlist:
https://www.youtube.com/playlist?list=PL8TYDcdO393yk5lf5RNA35w9EVyCt_VcG

Psuedocode Outine Google Doc:
https://docs.google.com/document/d/1yyXu-iXRud6IDKbNSqclHuFLLRphCGcXNsMJ-4qrOJU/edit?usp=sharing

Github: 
https://github.com/josephdevelops/CST-201/
