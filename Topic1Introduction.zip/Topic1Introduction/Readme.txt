Youtube video link:
https://www.youtube.com/watch?v=iF752aWln_0

Psuedocode Outine Google Doc:
https://docs.google.com/document/d/1ZcTTEVdTScoItK7W3h_ND0xkBw_mWAi9ir8stHimXSA/edit?usp=sharing

You can find this item at : 
https://github.com/josephdevelops/CST-201/tree/main/Topic1Introduction