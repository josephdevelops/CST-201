Youtube video link:
https://youtu.be/umd9OOuLFvg

Video playlist:
https://www.youtube.com/playlist?list=PL8TYDcdO393yk5lf5RNA35w9EVyCt_VcG

Psuedocode Outine Google Doc:
https://docs.google.com/document/d/1u5Ct0Mf8AwB6HftxRNlk0ZYRyQMc3cKA9GNDY0ElvDw/edit?usp=sharing

Github: 
https://github.com/josephdevelops/CST-201/tree/main/Topic2Complexity
https://github.com/josephdevelops/CST-201/
