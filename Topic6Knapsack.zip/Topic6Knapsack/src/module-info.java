/**
 * 
 */
/**
 * 
 */
module Topic6Knapsack {
}