Youtube video link:
https://youtu.be/g8DM8S9v3fU?si=0z6CqYU8e31dJPXr

Video playlist:
https://www.youtube.com/playlist?list=PL8TYDcdO393yk5lf5RNA35w9EVyCt_VcG

Psuedocode Outine Google Doc:
https://docs.google.com/document/d/1bubrx9t2KHlvieFj4lOBwXKRbZ8aIpYBSm_88XllUd4/edit?usp=sharing

Github: 
https://github.com/josephdevelops/CST-201/
