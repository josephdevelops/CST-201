Youtube video link:
https://youtu.be/q-zktR7tDKg

Video playlist:
https://www.youtube.com/playlist?list=PL8TYDcdO393yk5lf5RNA35w9EVyCt_VcG

Psuedocode Outine Google Doc:
https://docs.google.com/document/d/1XZqMCOv-wEVn0j2H_b0QIW7UGuuPZXiDbpm6jE_-yKs/edit?usp=sharing

Github: 
https://github.com/josephdevelops/CST-201/
